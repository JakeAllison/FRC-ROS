^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package common_sensors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2016-02-25)
------------------
* Added sources to repository 
* Contributors: Jennifer Buehler
